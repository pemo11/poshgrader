/*
 * Resistor.java
 *
 * Copyright (c) 2004-2013 HS Emden/Leer
 * All Rights Reserved.
 *
 * @version 1.00 - 02 November 2013 
 */

/** 
  A class that represents a resistor
  <br><code><b>[OMI-GP1-EA3]</b></code>
  
  @version 1.00 - 02 November 2013 
   
  @author Peter Monadjemi - pmonadjemi@live.de
 */

 public class Resistor {
	private ElectronicColorCode bandA;
	private ElectronicColorCode bandB;
	private ElectronicColorCode bandC;
	private ElectronicColorCode bandD;
	private double resistance;

	// Constructor
    /**
     * Creates a resistor with three bands
     * 
     * @param bandA            the first band
     * @param bandB            the second band
     * @param bandC            the third band
     */
	public Resistor(ElectronicColorCode bandA, ElectronicColorCode bandB,ElectronicColorCode bandC) {
		this.bandA = bandA;
		this.bandB = bandB;
		this.bandC = bandC;
	}
	
    // Methods

    /**
     * Returns bandA
     * 
     * @return - bandA
     */
	public ElectronicColorCode bandA() { return this.bandA; }

    /**
     * Returns bandB
     * 
     * @return - bandB
     */
	public ElectronicColorCode bandB() { return this.bandB; }

    /**
     * Returns bandC
     * 
     * @return - bandC
     */

	public ElectronicColorCode bandC() { return this.bandC; }

	/**
     * Returns bandD
     * 
     * @return - bandD
     */

	public ElectronicColorCode bandD() { return this.bandD; }

	/**
     * Returns the measured resistance value
     * 
     * @return - resistance value
     */

	public double resistance() {
		return  resistance;
	}
	
	/**
     * Returns the measured resistance value
     * 
     * @param color  - color for band D
     */

	public void setBandD(ElectronicColorCode color) {
		this.bandD = color;
	}
	
	/**
     * sets the measured resistance value
     * 
     * @param resistance  - resistance value
     */

	public void setResistance(double resistance) {
		this.resistance = resistance;
	}

	/**
     * returns all color codes of the resistor as an array of ElectronicColorCode values
     * 
     * @return  - array of ElectronicColorCode
     */
	public ElectronicColorCode[] values() {
		return new ElectronicColorCode[]{ this.bandA, this.bandB, this.bandC };
	}
	
	public String toString()
	{
		return "Bands: " + this.bandA.toString() + ", " + this.bandB.toString() +
				", " + this.bandC.toString() + ", " + this.bandD.toString() +
				" - Resistance: " + this.resistance() + " Ohm";
	}
}
