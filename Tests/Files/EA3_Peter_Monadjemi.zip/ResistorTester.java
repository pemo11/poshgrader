/*
 * ResistorTester.java
 *
 * Copyright (c) 2004-2013 HS Emden/Leer
 * All Rights Reserved.
 *
 * @version 1.00 - 02 November 2013
 */

/**
  A class for testing resistors with given color codes and a measured resistance value.
  <br><code><b>[OMI-GP1-EA3]</b></code>

  @version 1.00 - 02 November 2013

  @author Peter Monadjemi - pmonadjemi@live.de
 */

public class ResistorTester {

    /**
     Tests the functions of the resistor class by creating a resistor with three color codes.
     And analyzing the resistor with a measured value to get the tolerance band D for the resistor
     @param args - Commandline arguments
    */
    public static void main(String[] args) {
        // test a resistor with 22 Ohm
        Resistor r1 = new Resistor(ElectronicColorCode.RED, ElectronicColorCode.RED,
				                   ElectronicColorCode.BLACK);
        // sets the measured resistance value
        r1.setResistance(25);
        // calculate the tolerance and setting band D
        ToleranceStation.analyze(r1);
        System.out.println(r1);
        // test a resistor with 2200 Ohm
        Resistor r2 = new Resistor(ElectronicColorCode.RED, ElectronicColorCode.RED,
		                           ElectronicColorCode.RED);
		r2.setResistance(2198);
		ToleranceStation.analyze(r2);
		System.out.println(r2);
        // test a resistor with 2200 Ohm
        Resistor r3 = new Resistor(ElectronicColorCode.RED, ElectronicColorCode.RED,
				                   ElectronicColorCode.RED);
        r3.setResistance(2094);
        ToleranceStation.analyze(r3);
        System.out.println(r3);
        // test a resistor with 2200 Ohm
        Resistor r4 = new Resistor(ElectronicColorCode.RED, ElectronicColorCode.RED,
                                   ElectronicColorCode.RED);
        // test a resistor with 2200 Ohm
        r4.setResistance(2192);
        ToleranceStation.analyze(r4);
        System.out.println(r4);
        // test a resistor with 100 Ohm and low tolerance
        Resistor r5 = new Resistor(ElectronicColorCode.BLACK, ElectronicColorCode.BROWN,
				                   ElectronicColorCode.RED);
        r5.setResistance(99.8);
        ToleranceStation.analyze(r5);
        System.out.println(r5);
    }
}