/*
 * ElectronicColorCode.java
 *
 * Copyright (c) 2004-2013 HS Emden/Leer
 * All Rights Reserved.
 *
 * @version 1.00 - 02 November 2013 
 */

/** 
  A enum that represents all color codes of a resistor
  <br><code><b>[OMI-GP1-EA3]</b></code>
  
  @version 1.00 - 02 November 2013 
   
  @author Peter Monadjemi - pmonadjemi@live.de
 */

enum ElectronicColorCode {
	BLACK, 
	BROWN,
	RED,
	ORANGE,
	YELLOW,
	GREEN,
	BLUE ,
	VIOLET,
	GRAY,
	WHITE,
	GOLD,
	SILVER,
	NONE
}