/*
 * ToleranceStation.java
 *
 * Copyright (c) 2004-2013 HS Emden/Leer
 * All Rights Reserved.
 *
 * @version 1.00 - 02 November 2013 
 */

/** 
 * A class for calculating the tolerance of a resistor with a measured value
 * <br><code><b>[OMI-GP1-EA3]</b></code>
 * 
 * @version 1.00 - 02 November 2013 
 *  
 * @author Peter Monadjemi - pmonadjemi@live.de
 */

public class ToleranceStation {

    /**
     * sets the tolerance BandD of the resistor
     * 
     * @param - the resistor to test
    */

	public static void analyze(Resistor resistor) {
		// calculates the official resistance value
		long resistorOfficialValue =  (colorValue(resistor.bandA()) *  10 + colorValue(resistor.bandB()))
				                      * (int)Math.pow(10,  colorValue(resistor.bandC()));
		System.out.println("*** Debug: Official value: " + resistorOfficialValue);
		// calculates the difference between the official and the measured value
		double TolerancePercent = Math.abs(resistor.resistance() -
				resistorOfficialValue) / resistorOfficialValue * 100;
		System.out.println("*** Debug: Tolerance in %: " + TolerancePercent);
		// calculates the tolerance and sets band D
		resistor.setBandD(toleranceCode(TolerancePercent));
	}
	
    /**
     * gets the color value of an ElectronicColorCode
     * 
     * @param - the resistor to test
     * @return - the color value as an integer
    */

	private static int colorValue(ElectronicColorCode color) {
		switch(color) {
			case BLACK: 
				return 0;
			case BROWN:
				return 1;
			case RED:
				return 2;
			case ORANGE:
				return 3;
			case YELLOW:
				return 4;
			case GREEN:
				return 5;
			case BLUE:
				return 6;
			case VIOLET:
				return 7;
			case GRAY:
				return 8;
			case WHITE:
				return 9;
		default:
			break;
		}
		return 0;
	}
	
    /**
     * sets the tolerance BandD of the resistor
     * 
     * @param - the tolerance value as a double
    */
	private static ElectronicColorCode toleranceCode(double tolerance) {
		if (tolerance <= 0.1)
			return ElectronicColorCode.VIOLET;
		else if (tolerance <= 0.25) 
			return ElectronicColorCode.BLUE;
		else if (tolerance <= 0.5) 
			return ElectronicColorCode.GREEN;
		else if (tolerance <= 1) 
			return ElectronicColorCode.BROWN;
		else if (tolerance <= 2) 
			return ElectronicColorCode.RED;
		else if (tolerance <= 5) 
			return ElectronicColorCode.GOLD;
		else if (tolerance <= 10)
			return ElectronicColorCode.SILVER;
		else
			return ElectronicColorCode.NONE;
	}

}
